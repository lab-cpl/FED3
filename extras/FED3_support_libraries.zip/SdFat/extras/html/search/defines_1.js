var searchData=
[
  ['destructor_5fcloses_5ffile',['DESTRUCTOR_CLOSES_FILE',['../_sd_fat_config_8h.html#a9a2b1ca4d91cff876f48deeaacbc33da',1,'DESTRUCTOR_CLOSES_FILE():&#160;SdFatConfig.h'],['../_fat_lib_config_8h.html#a9a2b1ca4d91cff876f48deeaacbc33da',1,'DESTRUCTOR_CLOSES_FILE():&#160;FatLibConfig.h']]]
];
